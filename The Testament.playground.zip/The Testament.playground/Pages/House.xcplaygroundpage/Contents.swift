//:[Solve the Riddle](Riddle3)

import SwiftUI
import PlaygroundSupport
import Foundation
import AVFoundation
import CoreMedia
import UIKit

PlaygroundPage.current.setLiveView(View11())

struct View11: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica11.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("Ethan and Liam arrive at a huge opened gate with a plate that says: “Byrne Orphanage”. They walk inside the awful property and finally get to what seems the final point of their journey.")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{PlaygroundPage.current.setLiveView(View12())},
                           label: {
                        Text("Continue")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

struct View12: View {
    
    @State var scaledUp = true
    
    var body: some View {
                VStack {
                    Image(uiImage: UIImage(named: "grafica12.jpg")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 300)
                        .border(Color.black, width: 10)
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                        .rotationEffect(.degrees(180))
                    
                    Text("They enter in the abandoned structure and look for something that could explain why they were there. Ethan notices the entrance of a ceiling. They get inside and find a little box closed by means of an \nelectronic padlock.")
                        .frame(width: 400, height: 150)
                        .font(Font.custom("American Typewriter", size: 20.0))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
//                        .scaleEffect(scaledUp ? 0 : 1)
//                        .animation(.linear(duration: 0.9), value: scaledUp)
//                        .onTapGesture {scaledUp.toggle()}
                            
                    Button(action:{},
                           label: {
                        Text("Click on 'Solve the Riddle'")
                            .bold()
                            .font(Font.custom("American Typewriter", size: 20.0))
                            .foregroundColor(.brown)
                            .frame(width: 400, height: 100)
                            .position(x: 200, y: 10)
                            .shadow(radius: 10)
                            })
                    Image(uiImage: UIImage(named: "barra.png")!)
                        .resizable()
                    }
                .frame(width: 400, height: 600)
            }
}

var player: AVAudioPlayer?

func playSound() {
    guard let url = Bundle.main.url(forResource: "after2riddle", withExtension: "mp3") else { return }

    do {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)


        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        
        guard let player = player else { return }

        player.play()

    } catch let error {
        print(error.localizedDescription)
    }
}
playSound()

//:[Solve the Riddle](Riddle3)
